-- National County Sports System MySQL/MariaDB schema.
-- Select the target database before importing this file.
-- Then run: NCSM_SEED_PASSWORD='...' php seed_cli.php

CREATE TABLE IF NOT EXISTS counties (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    group_label VARCHAR(1) NOT NULL CHECK (group_label IN ('A', 'B', 'C', 'D')),
    code VARCHAR(10) NOT NULL UNIQUE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS sports_disciplines (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL,
    association_name VARCHAR(100) NOT NULL,
    association_code VARCHAR(10) NOT NULL UNIQUE,
    description TEXT,
    status VARCHAR(10) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(30) NOT NULL CHECK (role IN ('super_admin', 'admin', 'public_affairs', 'coach', 'county_coordinator', 'group_admin', 'lfa_administrator', 'lka_administrator', 'lba_administrator', 'laa_administrator', 'match_commissioner')),
    county_id INTEGER REFERENCES counties(id),
    group_label VARCHAR(1) CHECK (group_label IN ('A', 'B', 'C', 'D')),
    association_id INTEGER REFERENCES sports_disciplines(id),
    phone VARCHAR(20),
    status VARCHAR(10) NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'inactive')),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS players (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    date_of_birth DATE NOT NULL,
    gender VARCHAR(10) NOT NULL CHECK (gender IN ('male', 'female', 'other')),
    nationality VARCHAR(100) NOT NULL DEFAULT 'Liberian',
    national_identification_number VARCHAR(100) NULL,
    year_of_nscm VARCHAR(4) NOT NULL,
    age SMALLINT NOT NULL DEFAULT 0,
    city VARCHAR(100) NOT NULL DEFAULT '',
    last_club VARCHAR(200) NOT NULL DEFAULT '',
    current_club VARCHAR(200) NOT NULL DEFAULT '',
    county_id INTEGER NOT NULL REFERENCES counties(id),
    primary_position VARCHAR(50) NOT NULL,
    emergency_contact_name VARCHAR(100) NOT NULL DEFAULT '',
    emergency_contact_phone VARCHAR(20) NOT NULL DEFAULT '',
    emergency_contact_relation VARCHAR(50) NOT NULL DEFAULT '',
    medical_fitness_status VARCHAR(20) DEFAULT 'pending_review' CHECK (medical_fitness_status IN ('fit', 'unfit', 'pending_review')),
    medical_notes TEXT,
    photo_path VARCHAR(255),
    sport_discipline_id INTEGER NOT NULL REFERENCES sports_disciplines(id),
    registered_by INTEGER NOT NULL REFERENCES users(id),
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'submitted', 'approved', 'rejected')),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_players_county (county_id),
    INDEX idx_players_sport (sport_discipline_id),
    INDEX idx_players_status (status)
);

CREATE TABLE IF NOT EXISTS approval_workflow (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    player_id INTEGER NOT NULL REFERENCES players(id) ON DELETE CASCADE,
    action VARCHAR(20) NOT NULL CHECK (action IN ('submit', 'approve', 'reject', 'return_for_revision', 'draft')),
    action_by INTEGER NOT NULL REFERENCES users(id),
    role_at_time VARCHAR(30) NOT NULL CHECK (role_at_time IN ('county_coordinator', 'group_admin', 'lfa_administrator', 'lka_administrator', 'lba_administrator', 'laa_administrator', 'super_admin', 'admin', 'coach', 'match_commissioner')),
    comments TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_approval_player (player_id)
);

CREATE TABLE IF NOT EXISTS matches (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    sport_discipline_id INTEGER NOT NULL REFERENCES sports_disciplines(id),
    home_county_id INTEGER NOT NULL REFERENCES counties(id),
    away_county_id INTEGER NOT NULL REFERENCES counties(id),
    home_score INTEGER,
    away_score INTEGER,
    match_date TIMESTAMP NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'scheduled' CHECK (status IN ('scheduled', 'live', 'completed')),
    group_label VARCHAR(1) NOT NULL CHECK (group_label IN ('A', 'B', 'C', 'D')),
    round VARCHAR(50) DEFAULT 'Group Stage',
    notes TEXT,
    created_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    timer_kickoff TIMESTAMP NULL DEFAULT NULL,
    timer_offset INTEGER NOT NULL DEFAULT 0,
    extra_time_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    INDEX idx_matches_sport (sport_discipline_id),
    INDEX idx_matches_group (group_label),
    INDEX idx_matches_status (status)
);

CREATE TABLE IF NOT EXISTS match_goals (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    match_id INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
    team VARCHAR(10) NOT NULL CHECK (team IN ('home', 'away')),
    player_name VARCHAR(100) NOT NULL DEFAULT '',
    jersey_number INTEGER NOT NULL DEFAULT 0,
    minute INTEGER,
    goal_type VARCHAR(20) DEFAULT 'normal' CHECK (goal_type IN ('normal', 'penalty', 'own_goal')),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS match_reports (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    match_id INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
    commissioner_id INTEGER NOT NULL REFERENCES users(id),
    home_yellow_cards INTEGER DEFAULT 0,
    home_red_cards INTEGER DEFAULT 0,
    away_yellow_cards INTEGER DEFAULT 0,
    away_red_cards INTEGER DEFAULT 0,
    notes TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS match_report_cards (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    report_id INTEGER NOT NULL REFERENCES match_reports(id) ON DELETE CASCADE,
    team VARCHAR(10) NOT NULL CHECK (team IN ('home', 'away')),
    card_type VARCHAR(10) NOT NULL CHECK (card_type IN ('yellow', 'red')),
    jersey_number INTEGER NOT NULL,
    player_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS match_squad_players (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    report_id INTEGER NOT NULL REFERENCES match_reports(id) ON DELETE CASCADE,
    team VARCHAR(10) NOT NULL CHECK (team IN ('home', 'away')),
    player_type VARCHAR(20) NOT NULL CHECK (player_type IN ('starting', 'substitute')),
    jersey_number INTEGER NOT NULL,
    player_name VARCHAR(100) NOT NULL,
    position VARCHAR(50) NOT NULL DEFAULT '',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS coach_lineups (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    match_id INTEGER NOT NULL REFERENCES matches(id) ON DELETE CASCADE,
    county_id INTEGER NOT NULL REFERENCES counties(id),
    coach_id INTEGER NOT NULL REFERENCES users(id),
    formation VARCHAR(20) NOT NULL DEFAULT '4-3-3',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (match_id, county_id)
);

CREATE TABLE IF NOT EXISTS coach_lineup_players (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    lineup_id INTEGER NOT NULL REFERENCES coach_lineups(id) ON DELETE CASCADE,
    player_id INTEGER REFERENCES players(id) ON DELETE SET NULL,
    player_type VARCHAR(20) NOT NULL CHECK (player_type IN ('starting', 'substitute')),
    jersey_number INTEGER NOT NULL,
    player_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS coach_lineup_substitutions (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    lineup_id INTEGER NOT NULL REFERENCES coach_lineups(id) ON DELETE CASCADE,
    outgoing_player_id INTEGER REFERENCES players(id) ON DELETE SET NULL,
    incoming_player_id INTEGER REFERENCES players(id) ON DELETE SET NULL,
    outgoing_player_name VARCHAR(100) NOT NULL,
    incoming_player_name VARCHAR(100) NOT NULL,
    outgoing_jersey_number INTEGER NOT NULL,
    incoming_jersey_number INTEGER NOT NULL,
    position VARCHAR(50) NOT NULL,
    game_minute VARCHAR(20) NOT NULL DEFAULT '',
    substituted_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS documents (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    description TEXT,
    file_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_type VARCHAR(100) NOT NULL,
    file_size INTEGER NOT NULL,
    uploaded_by INTEGER NOT NULL REFERENCES users(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_documents_uploaded (uploaded_by)
);

CREATE TABLE IF NOT EXISTS notifications (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    type VARCHAR(10) DEFAULT 'info' CHECK (type IN ('info', 'success', 'warning', 'danger')),
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    link VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_notifications_user (user_id)
);

CREATE TABLE IF NOT EXISTS activity_logs (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    action VARCHAR(100) NOT NULL,
    description TEXT,
    ip_address VARCHAR(45),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_logs_user (user_id)
);

CREATE TABLE IF NOT EXISTS contact_messages (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    full_name VARCHAR(100) NOT NULL,
    email VARCHAR(150) NOT NULL,
    phone VARCHAR(20),
    subject VARCHAR(200) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS gallery_photos (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    category_slug VARCHAR(100) NOT NULL,
    category_title VARCHAR(200) NOT NULL,
    photo_path VARCHAR(255) NOT NULL,
    caption VARCHAR(255) DEFAULT '',
    sort_order INTEGER DEFAULT 0,
    uploaded_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS videos (
    id INTEGER NOT NULL AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,
    video_type VARCHAR(10) NOT NULL DEFAULT 'file' CHECK (video_type IN ('file', 'url')),
    video_path VARCHAR(255),
    embed_url VARCHAR(500),
    description TEXT,
    thumbnail_path VARCHAR(255),
    sort_order INTEGER DEFAULT 0,
    uploaded_by INTEGER REFERENCES users(id),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
